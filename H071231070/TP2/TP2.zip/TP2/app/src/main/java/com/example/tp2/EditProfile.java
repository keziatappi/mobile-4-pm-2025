package com.example.tp2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditProfile extends AppCompatActivity {

    private ImageView imgProfile; // Tambahkan ImageView untuk gambar profil
    private EditText etName, etUsername, etPronouns, etBio; // Tambahkan EditText untuk input teks
    private ImageView ivCheck, ivBack; // Tambahkan ImageView untuk ikon check
    private Uri imageUri; // simpan uri gambar


    // method onCreate untuk mengatur tampilan dan logika aplikasi
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_profile);

        // Inisialisasi elemen-elemen UI dari layout berdasarkan ID nya
        imgProfile = findViewById(R.id.imgProfile);
        etName = findViewById(R.id.etName);
        etUsername = findViewById(R.id.etUsername);
        etPronouns = findViewById(R.id.etPronouns);
        etBio = findViewById(R.id.etBio);
        ivCheck = findViewById(R.id.ivCheck);
        ivBack = findViewById(R.id.ivBack);

        // fungsi untuk kembali ke activity sebelumnya
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditProfile.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // fungsi untuk foto profil, kalau foto profil ditekan bisa memilih foto dari galeri
        imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bukagaleri = new Intent(Intent.ACTION_GET_CONTENT);
                bukagaleri.setType("image/*");
                openGallery.launch(Intent.createChooser(bukagaleri, "Choose a picture"));
            }
        });

        // fungsi untuk button check, fungsinya untuk simpan data yang diinput oleh user
        ivCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // inisialisasikan variabel untuk simpan data
                String name = "";
                String username = "";
                String pronouns = "";
                String bio = "";

                // ambil inputan dari edit textnya name untuk simpan ke name
                if (etName.getText() != null) {
                    name = etName.getText().toString();
                }

                // ambil inputan dari edit textnya username untuk simpan ke username
                if (etUsername.getText() != null) {
                    username = etUsername.getText().toString();
                }

                // ambil inputan dari edit textnya pronouns untuk simpan ke pronouns
                if (etPronouns.getText() != null) {
                    pronouns = etPronouns.getText().toString();
                }

                // ambil inputan dari edit textnya bio untuk simpan ke bio
                if (etBio.getText() != null) {
                    bio = etBio.getText().toString();
                }

                // ambil inputan dari edit textnya imageuri untuk simpan ke imageuri
                String imageUriString = "";
                if (imageUri != null) {
                    imageUriString = imageUri.toString();
                }

                // buat objek dari class user yang sudah dibuat sebelumnya
                User user = new User(name, username, pronouns, bio, imageUriString);

                // buat intent untuk berpindah ke MainActivity
                Intent intent = new Intent(EditProfile.this, MainActivity.class);

                // tambahkan data user ke intent
                intent.putExtra("USER_DATA", user);

                // memulai activity baru (mainactivity)
                startActivity(intent);
                finish();
            }
        });
//        ambil data dari intent sebelumnya
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("USER_DATA")) {
            User user = intent.getParcelableExtra("USER_DATA");

            if (user != null) {
                etName.setText(user.getName());
                etUsername.setText(user.getUsername());
                etPronouns.setText(user.getPronouns());
                etBio.setText(user.getBio());

                if (user.getImageUri() != null && !user.getImageUri().isEmpty()) {
                    imageUri = Uri.parse(user.getImageUri());
                    imgProfile.setImageURI(imageUri);
                }
            }
        }
    }
    // ini fungsi untuk memilih foto dari galeri
    ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            imageUri = data.getData();
                            imgProfile.setImageURI(imageUri);
                        }
                    }
                }
            }
    );
}